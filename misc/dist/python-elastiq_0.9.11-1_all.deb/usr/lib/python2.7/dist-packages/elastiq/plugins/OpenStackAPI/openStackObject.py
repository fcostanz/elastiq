class OpenStackObject():
    def __init__(self, _id):
        self.id = _id

    def startElement(self, connection = None):
        pass
